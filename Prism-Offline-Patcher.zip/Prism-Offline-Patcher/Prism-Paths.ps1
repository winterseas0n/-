function Resolve-PrismPaths {
    param([string]$Executable, [string]$DataDirectory)
    if (!$Executable) {
        $candidates = @()
        $candidates += @(Get-Process prismlauncher -ErrorAction SilentlyContinue | ForEach-Object { $_.Path })
        $candidates += @(
            "$env:LOCALAPPDATA\Programs\PrismLauncher\prismlauncher.exe",
            "$env:ProgramFiles\PrismLauncher\prismlauncher.exe",
            "${env:ProgramFiles(x86)}\PrismLauncher\prismlauncher.exe",
            (Join-Path $PSScriptRoot 'prismlauncher.exe'),
            (Join-Path (Split-Path $PSScriptRoot -Parent) 'prismlauncher.exe')
        )
        $command = Get-Command prismlauncher.exe -ErrorAction SilentlyContinue
        if ($command) { $candidates += $command.Source }
        foreach ($registry in @(
            'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )) {
            foreach ($entry in @(Get-ItemProperty -Path $registry -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like '*Prism*Launcher*' })) {
                if ($entry.InstallLocation) { $candidates += Join-Path $entry.InstallLocation 'prismlauncher.exe' }
                if ($entry.DisplayIcon -match '^"?(.+?\.exe)"?(?:,\d+)?$') { $candidates += $Matches[1] }
            }
        }
        $found = @($candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) -and (Split-Path $_ -Leaf) -eq 'prismlauncher.exe' } | ForEach-Object { (Get-Item -LiteralPath $_).FullName } | Select-Object -Unique)
        if ($found.Count -eq 1) { $Executable = $found[0] }
        elseif ($found.Count -gt 1) {
            Write-Host 'Multiple installations found:'
            for ($i = 0; $i -lt $found.Count; $i++) { Write-Host "$($i + 1). $($found[$i])" }
            do { $choice = Read-Host 'Installation number'; $number = 0 }
            until ([int]::TryParse($choice, [ref]$number) -and $number -ge 1 -and $number -le $found.Count)
            $Executable = $found[$number - 1]
        } else {
            $Executable = (Read-Host 'Prism not found. Paste the full path to prismlauncher.exe').Trim().Trim('"')
        }
    }
    $Executable = [IO.Path]::GetFullPath($Executable)
    if (!(Test-Path -LiteralPath $Executable -PathType Leaf) -or (Split-Path $Executable -Leaf) -ne 'prismlauncher.exe') {
        throw 'prismlauncher.exe was not found at the selected path.'
    }
    if (!$DataDirectory) {
        $installDirectory = Split-Path $Executable -Parent
        if ((Test-Path -LiteralPath (Join-Path $installDirectory 'portable.txt')) -or
            (Test-Path -LiteralPath (Join-Path $installDirectory 'prismlauncher.cfg'))) {
            $DataDirectory = $installDirectory
        } else { $DataDirectory = Join-Path $env:APPDATA 'PrismLauncher' }
    }
    $DataDirectory = [IO.Path]::GetFullPath($DataDirectory)
    if (!(Test-Path -LiteralPath (Join-Path $DataDirectory 'prismlauncher.cfg'))) {
        throw 'Prism configuration not found. Run Prism once, finish initial setup, then close it and retry. For custom data folders use -DataDirectory.'
    }
    [pscustomobject]@{ Executable = $Executable; DataDirectory = $DataDirectory }
}
