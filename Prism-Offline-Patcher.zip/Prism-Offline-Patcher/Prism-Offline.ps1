param(
    [ValidatePattern('^[A-Za-z0-9_]{3,16}$')][string]$Username,
    [string]$DataDirectory,
    [string]$Executable,
    [switch]$Apply,
    [switch]$Restart
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Prism-Paths.ps1')
$paths = Resolve-PrismPaths -Executable $Executable -DataDirectory $DataDirectory
$Executable = $paths.Executable
$DataDirectory = $paths.DataDirectory
Write-Host "Prism: $Executable"
Write-Host "Data:  $DataDirectory"
if (!$Username) {
    do {
        $Username = Read-Host 'Enter your nickname (3-16 letters A-Z, digits or underscore)'
        if ($Username -notmatch '^[A-Za-z0-9_]{3,16}$') { Write-Host 'Invalid nickname. Try again.' }
    } until ($Username -match '^[A-Za-z0-9_]{3,16}$')
}
$accountFile = Join-Path $DataDirectory 'accounts.json'
if (!(Test-Path -LiteralPath (Join-Path $DataDirectory 'prismlauncher.cfg'))) {
    throw "Prism data directory not found: $DataDirectory"
}
if (!$Apply) {
    Write-Host "Preview: add/select offline profile '$Username' in $accountFile. Use -Apply to write."
    return
}
$processes = @(Get-Process prismlauncher -ErrorAction SilentlyContinue)
foreach ($process in $processes) {
    $null = $process.CloseMainWindow()
    if (!$process.WaitForExit(3000)) {
        Write-Host 'Close Prism and its dialogs/tray icon. Do not close Minecraft through Task Manager.'
        $null = Read-Host 'Press Enter after closing Prism'
        if (!$process.WaitForExit(1000)) { throw 'Prism is still running. Exit Prism and run this file again.' }
    }
}
$root = [pscustomobject]@{ formatVersion = 3; accounts = @() }
if (Test-Path -LiteralPath $accountFile) {
    $root = Get-Content -LiteralPath $accountFile -Raw | ConvertFrom-Json
    if ($root.formatVersion -ne 3) { throw 'Unsupported accounts format; no changes made.' }
    $backup = "$accountFile.backup-$([DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff'))"
    Copy-Item -LiteralPath $accountFile -Destination $backup
    Write-Host "Backup: $backup"
}
& (Join-Path $PSScriptRoot 'Prism-EnableOffline.ps1') -Executable $Executable
$md5 = [Security.Cryptography.MD5]::Create()
try { $digest = $md5.ComputeHash([Text.Encoding]::UTF8.GetBytes("OfflinePlayer:$Username")) }
finally { $md5.Dispose() }
$digest[6] = ($digest[6] -band 15) -bor 48
$digest[8] = ($digest[8] -band 63) -bor 128
$uuid = ([BitConverter]::ToString($digest)).Replace('-', '').ToLowerInvariant()
$accounts = @($root.accounts | Where-Object { $_.type -ne 'Offline' -or $_.profile.id -ne $uuid })
foreach ($account in $accounts) {
    $account | Add-Member -NotePropertyName active -NotePropertyValue $false -Force
}
$accounts += [pscustomobject]@{
    type = 'Offline'
    active = $true
    profile = @{
        id = $uuid; name = $Username
        skin = @{ id = ''; url = ''; variant = '' }
        capes = @()
    }
    ygg = @{
        token = '0'
        iat = [long]([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
        extra = @{ userName = $Username; clientToken = [guid]::NewGuid().ToString('N') }
    }
}
$root.accounts = @($accounts)
$json = $root | ConvertTo-Json -Depth 100
$null = $json | ConvertFrom-Json
$tempFile = "$accountFile.$([guid]::NewGuid().ToString('N')).tmp"
[IO.File]::WriteAllText($tempFile, $json, [Text.UTF8Encoding]::new($false))
if (Test-Path -LiteralPath $accountFile) {
    [IO.File]::Replace($tempFile, $accountFile, $backup)
} else {
    [IO.File]::Move($tempFile, $accountFile)
}
Write-Host "Applied offline profile: $Username ($uuid)"
if ($Restart) {
    Start-Process -FilePath $Executable -ArgumentList @('--dir', ('"' + $DataDirectory + '"')) -WindowStyle Hidden
}
