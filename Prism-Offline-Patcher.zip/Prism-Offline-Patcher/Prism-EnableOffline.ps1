param(
    [string]$Executable = "$env:LOCALAPPDATA\Programs\PrismLauncher\prismlauncher.exe",
    [switch]$Restore
)
$ErrorActionPreference = 'Stop'
$originalHash = '19AD665668CA6C80AA5368573DD8F61CFCE2A483CE9D5A6CCCD7802C221D36A0'
$backup = "$Executable.original-11.1.1"
if (Get-Process prismlauncher -ErrorAction SilentlyContinue) {
    throw 'Close Prism Launcher, including its tray icon, before patching.'
}
if ($Restore) {
    if (!(Test-Path -LiteralPath $backup)) { throw 'Original executable backup is missing.' }
    if ((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne $originalHash) {
        throw 'Backup hash mismatch; refusing to restore.'
    }
    Copy-Item -LiteralPath $backup -Destination $Executable -Force
    Write-Host 'Original Prism Launcher restored.'
    return
}
$bytes = [IO.File]::ReadAllBytes($Executable)
function Get-FileOffset([int]$rva) {
    $pe = [BitConverter]::ToInt32($bytes, 0x3c)
    $count = [BitConverter]::ToUInt16($bytes, $pe + 6)
    $section = $pe + 24 + [BitConverter]::ToUInt16($bytes, $pe + 20)
    for ($i = 0; $i -lt $count; $i++) {
        $entry = $section + 40 * $i
        $va = [BitConverter]::ToUInt32($bytes, $entry + 12)
        $size = [BitConverter]::ToUInt32($bytes, $entry + 16)
        if ($rva -ge $va -and $rva -lt ($va + $size)) {
            return [int]([BitConverter]::ToUInt32($bytes, $entry + 20) + $rva - $va)
        }
    }
    throw 'Patch RVA is outside file sections.'
}
$patches = @(
    # AccountList::anyAccountIsValid: accept a populated offline account.
    @{ Rva = 0xb61b5; Old = [byte[]](0x74,0x09); New = [byte[]](0x74,0x41) },
    # LaunchController::decideLaunchMode: use the selected offline profile.
    @{ Rva = 0xeb568; Old = [byte[]](0x0f,0x84,0x68,0x01,0x00,0x00); New = [byte[]](0x90,0x90,0x90,0x90,0x90,0x90) }
)
$hash = (Get-FileHash -LiteralPath $Executable -Algorithm SHA256).Hash
if ($hash -ne $originalHash) {
    if (!(Test-Path -LiteralPath $backup) -or (Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne $originalHash) {
        throw 'Unsupported executable: this patch supports only the inspected Prism 11.1.1 build.'
    }
    $expected = [IO.File]::ReadAllBytes($backup)
    foreach ($patch in $patches) {
        $offset = Get-FileOffset $patch.Rva
        [Array]::Copy($patch.New, 0, $expected, $offset, $patch.New.Length)
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $expectedHash = ([BitConverter]::ToString($sha.ComputeHash($expected))).Replace('-', '') }
    finally { $sha.Dispose() }
    if ($hash -ne $expectedHash) { throw 'Unexpected modified executable; refusing to overwrite.' }
    Write-Host 'Offline launch patch is already installed.'
    return
}
foreach ($patch in $patches) {
    $offset = Get-FileOffset $patch.Rva
    for ($i = 0; $i -lt $patch.Old.Length; $i++) {
        if ($bytes[$offset + $i] -ne $patch.Old[$i]) { throw 'Original instruction mismatch.' }
    }
    [Array]::Copy($patch.New, 0, $bytes, $offset, $patch.New.Length)
}
if (Test-Path -LiteralPath $backup) {
    if ((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne $originalHash) { throw 'Unexpected existing backup.' }
} else { Copy-Item -LiteralPath $Executable -Destination $backup }
[IO.File]::WriteAllBytes($Executable, $bytes)
Write-Host 'Offline launch patch installed. Original saved beside the executable.'
