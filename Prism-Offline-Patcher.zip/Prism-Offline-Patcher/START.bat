@echo off
setlocal
title Prism Offline Setup
if not exist "%~dp0Prism-Offline.ps1" (
  echo Extract ALL files from the ZIP into one folder first.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Prism-Offline.ps1" -Apply -Restart
if errorlevel 1 (
  echo.
  echo Setup failed. Read the error above. No need to reinstall Minecraft.
  pause
  exit /b 1
)
echo.
echo Done! Your nickname is selected. Launch your instance in Prism.
pause
